#!/bin/bash
echo "Id. usuario del trabajo: daniicereezo"
echo "Id. del trabajo: -"
echo "Nombre del trabajo especificado por usuario: SumaVectoresPC"
echo "Directorio de trabajo (en el que se ejecuta el script): bp1/ejer9"
echo "Cola: -"
echo "Nodo que ejecuta este trabajo: -"
echo "Nº de nodos asignados al trabajo: -"
echo "Nodos asignados al trabajo: -"
echo "CPUs por nodo: 2"
#Instrucciones del script para ejecutar código:
echo -e "\n1. Ejecución sp-OpenMP.\n"
for ((N=16384;N<=67108864;N=N*2))
do
./Listado1 $N
done

echo -e "\n2. Ejecución sp-OpenMP-for.\n"
for ((N=16384;N<=67108864;N=N*2))
do
./sp-OpenMP-for $N
done

echo -e "\n3. Ejecución sp-OpenMP-sections.\n"
for ((N=16384;N<=67108864;N=N*2))
do
./sp-OpenMP-sections $N
done
