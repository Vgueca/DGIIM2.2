package deepspace;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author valenting
 */
public class TestP1 {
    
    public static void main(String[] args){
        Loot l1 = new Loot(1 , 2, 3, 4, 5);         //Comprobamos constructor por parametros
        Loot l2 = new Loot(0, 50, 100, 150, 200);
        
        System.out.println("LOOT: \n");
        System.out.println("L1: " + l1.getNHangars() + " nHangars " + l1.getNMedals() + " nMedals " + l1.getNShields() + " nShields " + l1.getNSupplies() + " nSupplies " + l1.getNWeapons() + " nWeapons\n");
        System.out.println("L2: " + l2.getNHangars() + " nHangars " + l2.getNMedals() + " nMedals " + l2.getNShields() + " nShields " + l2.getNSupplies() + " nSupplies " + l2.getNWeapons() + " nWeapons\n");
    
        
        SuppliesPackage sp1 = new SuppliesPackage(1,2,3);   //Comprobamos constructor por parametros
        SuppliesPackage sp = new SuppliesPackage(10,20,30);
        SuppliesPackage sp2 = new SuppliesPackage(sp);     //Comprobamos constructor por copia
        
        System.out.println("SUPPLIESPACKAGE: \n");
        System.out.println("SP1: " + sp1.getammoPower() + " ammoPower " + sp1.getfuelUnits() +  " fuelUnits " + sp1.getshieldPower() + " shieldPower \n" );
        System.out.println("SP2: " + sp2.getammoPower() + " ammoPower " + sp2.getfuelUnits() +  " fuelUnits " + sp2.getshieldPower() + " shieldPower \n" );
        
        
        
        ShieldBooster sb1 = new ShieldBooster("juan", 10, 1);       //Comprobamos constructor por parametros
        ShieldBooster sb = new ShieldBooster("valentin", 5, 2); 
        ShieldBooster sb2 = new ShieldBooster(sb);                 //Comprobamos constructor por copia
        
        System.out.println("SHIELDBOOSTER: \n");
        System.out.println("SB1: " + sb1.getBoost() + " Boost " + sb1.getUses() + " uses\n");
        System.out.println("SB2: " + sb2.getBoost() + " Boost " + sb2.getUses() + " uses\n");
    
        
        
        
        Weapon w1 = new Weapon("laser", WeaponType.LASER, 2);       //Comprobamos constructor por parametros
        Weapon w = new Weapon("plasma", WeaponType.PLASMA, 1);      
        Weapon w2 = new Weapon(w);                                  //Comprobamos constructor por copia
        
        
        System.out.println("WEAPON: \n");
        
        System.out.println("W1: " + w1.getType() + " Type " + w1.getUses() + " uses " + w1.power() + " power \n");
        System.out.println(w1.useIt() + "\n" );
        
        System.out.println("Despues de un uso de w1: \n");
        System.out.println("W1: " + w1.getType() + " Type " + w1.getUses() + " uses " + w1.power() + " power \n");
        
        
        
        System.out.println("W2: " + w2.getType() + " Type " + w2.getUses() + " uses " + w1.power() + " power \n");
        
        System.out.println(w2.useIt() + "\n" );
        
        System.out.println("Despues de un uso de w2: \n");
        System.out.println("W1: " + w2.getType() + " Type " + w2.getUses() + " uses " + w2.power() + " power \n");
        
        System.out.println(w2.useIt() + "\n" );
        
        System.out.println("Despues de dos usos de w2: \n");
        System.out.println("W1: " + w2.getType() + " Type " + w2.getUses() + " uses " + w2.power() + " power \n");
        
        
        
        
        Dice d1 = new Dice();           //Comprobamos constructor
        
        for(int i = 0; i < 100; i++){             //Iteramos cada uno de las funciones que dependen de un número random 100 veces, así comprobamos que de verdad su resultado es aleatorio
            System.out.println("Iteration " + i + "\n");
            System.out.println("Init with " + d1.initWithNHangars() + " hangars\n");
            System.out.println("Init with " + d1.initWithNWeapons() + " weapons\n");
            System.out.println("Init with " + d1.initWithNShields() + " shields\n");
            System.out.println("Start player number " + d1.whoStarts(i) + " \n");
            System.out.println("First shot by:  " + d1.firstShot() + " \n");
            
            if(d1.spaceStationMoves(1/(i+1))){
                System.out.println("Shot have been dodged!!!  :) \n");
            }
            else{
                System.out.println("Shot haven't been dodged!! :( \n");
            }
        }
  
    }
}
