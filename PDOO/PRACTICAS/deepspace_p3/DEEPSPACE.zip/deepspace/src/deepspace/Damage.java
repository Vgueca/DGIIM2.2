/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package deepspace;

import java.util.ArrayList;

/**
 *
 * @author valenting
 */
public class Damage {
    private int nShields;
    private int nWeapons;
    
    private ArrayList<WeaponType> weapons;
    
    Damage(int w, int s){
        nShields = s;
        nWeapons = w;
        weapons = null;
    }
    Damage(ArrayList<WeaponType> wl, int s){
        nShields = s;
        nWeapons = -1;
        weapons = new ArrayList<>(wl);
        
    }
    Damage(Damage d){
        nShields  = d.getNShields();
        nWeapons = d.getNWeapons();
        weapons = new ArrayList<>(d.getWeapons());
    }
    
    int arrayContainsType(ArrayList<Weapon> w, WeaponType t){
        int index = -1;
        boolean end = false;
        
        for(int i =0; i < w.size() && !end; i++){
            if(w.get(i).getType() == t){
                index = i;
                end = true;
            }
        }
        return index;
    }
    
    Damage adjust(ArrayList<Weapon> w, ArrayList<ShieldBooster> s){
        if(weapons == null){
            int min;
            int min2;
            
            if(s.size() < nShields){
                min = s.size();
            }
            else{
                min = nShields;
            }
            if(w.size() < nWeapons){
                min2 = s.size();
            }
            else{
                min2 = nWeapons;
            }
            Damage adjusted = new Damage(min2, min);
            return adjusted;
        }
        else{
            boolean found = false, end = false;
            int min;
            ArrayList<WeaponType> w2 = new ArrayList<>();
            
            if(s.size() < nShields){
                min = s.size();
            }
            else{
                min = nShields;
            }
            
            ArrayList<Weapon> waux = new ArrayList<>(w);
            int j;
            for(int i=0; i < weapons.size(); i++){
                for(j =0; j < waux.size() && !end; j++ ){  
                    if(weapons.get(i) == waux.get(j).getType()){
                       found = true;
                       end = true;
                    }
                }
                if(found){
                    w2.add(weapons.get(i));
                    waux.remove(j-1);
                }
                found = false;
                end = false; 
            }
            
            Damage adjusted = new Damage(w2,min);
            return adjusted;
        }
        
    }
    
    
    void discardWeapon(Weapon w){
        if(weapons != null){
            weapons.remove(w.getType());
        }
        else{
            if(nWeapons >0){
                nWeapons--;
            }
        }
        
    }

    void discardShieldBooster(){
        if(nShields>0){
            nShields--;
        }
    }
    
    
    boolean hasNoeffect(){
        //return (nWeapons==0 && nShields == 0 && nShields == 0 && weapons == null);   
        if (nWeapons==0 && weapons == null && nShields==0)
            return true;
        
        else if (nWeapons == -1 && weapons.isEmpty() && nShields == 0)
            return true;
        else
            return false;

    }
    
    
    public int getNShields(){
        return nShields;
    }
    
    public int getNWeapons(){
        return nWeapons;
    }
    
    public ArrayList<WeaponType> getWeapons(){
        return weapons;
    }
    
    DamageToUI getUIversion() {
        return new DamageToUI(this);
    }
    
    @Override
    public String toString(){
        String mens2;
        if(weapons == null){
            mens2 = " ";
        }
        else{
            mens2 = weapons.toString();
        }
 
        String message = "[Damage]: Number of Shields: " + getNShields()
                + ", Number of Weapons: " + getNWeapons()
                + ", Weapon Type: " + mens2;
    
        return message;
    }

}
