# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative 'ShotResult'
require_relative 'EnemyToUI'
require_relative 'ShieldBooster'
require_relative 'Damage'
require_relative 'Loot'

class EnemyStarShip
    def initialize(n,a,s,l,d)
        @name = n
        @ammoPower = a
        @shieldPower = s
        @loot = l
        @damage = d
    end
    
    attr_reader :name, :ammoPower, :shieldPower, :loot , :damage
    
    def self.newCopy(e)
        new(e.name, e.ammoPower, e.shieldPower, e.loot, e.damage)
    end

    def fire
        @ammoPower
    end

    def protection
        @shieldPower
    end

    def receiveShot(shot)
        if shot > protection
            return ShotResult::DONOTRESIST
        else
            return ShotResult::RESIST
        end
    end

    def getUIversion
        Deepspace::EnemyToUI.new(self)
    end

    def to_s
        message = "[EnemyStarship]: Name: " + @name.to_s +
                ", Protection: " + protection.to_s +
                ", Fire: " + fire.to_s +
                ", Loot: " + @loot.to_s +
                ", Damage: " + @damage.to_s 
        
        return message
    end
end
