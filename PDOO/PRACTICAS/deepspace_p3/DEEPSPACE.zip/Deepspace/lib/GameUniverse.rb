# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative 'GameStateController'
require_relative 'Dice'
require_relative 'GameCharacter'
require_relative 'ShotResult'
require_relative 'CombatResult'
require_relative 'GameState'
require_relative 'SpaceStation'
require_relative 'EnemyStarShip'
require_relative 'CardDealer'
require_relative 'GameUniverseToUI'

module Deepspace
  
  class GameUniverse
      @@WIN = 10

      def initialize
          @gameState = GameStateController.new
          @turns = 0
          @dice = Dice.new
      end

      def combatGo(station, enemy)
          ch = @dice.firstShot

          if ch==GameCharacter::ENEMYSTARSHIP
              fire = enemy.fire
              result = station.receiveShot(fire)
              if result == ShotResult::RESIST
                  fire = station.fire
                  result = enemy.receiveShot(fire)
                  enemyWins = (result == ShotResult::RESIST)
              else
                  enemyWins = true
              end
          else
              fire = station.fire
              result = enemy.receiveShot(fire)

              enemyWins = (result == ShotResult::RESIST)
          end

          if enemyWins
              s = station.getSpeed
              moves = @dice.spaceStationMoves(s)

              if !moves
                  damage = enemy.damage
                  station.setPendingDamage(damage)
                  combatResult = CombatResult::ENEMYWINS
              else
                  station.move
                  combatResult = CombatResult::STATIONESCAPES
              end
          else
              aLoot = enemy.loot
              station.setLoot(aLoot)
              combatResult = CombatResult::STATIONWINS
          end

          @gameState.next(@turns, @spaceStations.length)

          return combatResult
      end

      def combat
          state = @gameState.state

          if state == GameState::BEFORECOMBAT || state == GameState::INIT
              return combatGo(@currentStation, @currentEnemy)
          else
              return CombatResult::NOCOMBAT
          end
      end

      def discardHangar
          if @gameState.state == GameState::INIT || @gameState.state == GameState::AFTERCOMBAT
              @currentStation.discardHangar
          end
      end

      def discardShieldBooster(i)
          if @gameState.state == GameState::INIT || @gameState.state == GameState::AFTERCOMBAT
              @currentStation.discardShieldBooster(i)
          end
      end

      def discardShieldBoosterInHangar(i)
          if @gameState.state == GameState::INIT || @gameState.state == GameState::AFTERCOMBAT
              @currentStation.discardShieldBoosterInHangar(i)
          end
      end

      def discardWeapon(i)
          if @gameState.state == GameState::INIT || @gameState.state == GameState::AFTERCOMBAT
              @currentStation.discardWeapon(i)
          end
      end

      def discardWeaponInHangar(i)
          if @gameState.state == GameState::INIT || @gameState.state == GameState::AFTERCOMBAT
              @currentStation.discardWeaponInHangar(i)
          end
      end

      def state
          @gameState.state
      end

      def haveAWinner
          (@currentStation.nMedals == @@WIN)
      end

      def init(names)
          state = @gameState.state

          if state == GameState::CANNOTPLAY
              @spaceStations = Array.new
              dealer = Deepspace::CardDealer.instance
              i = 0
              size = names.length

              while i<size
                  supplies = dealer.nextSuppliesPackage
                  s_i = SpaceStation.new(names[i], supplies)

                  nh = @dice.initWithNHangars
                  nw = @dice.initWithNWeapons
                  ns = @dice.initWithNShields

                  lo = Loot.new(0, nw, ns, nh, 0)

                  s_i.setLoot(lo)

                  @spaceStations.push(s_i)

                  i += 1
              end

              @currentStationIndex = @dice.whoStarts(size)
              @currentStation = @spaceStations[@currentStationIndex]
              @currentEnemy = dealer.nextEnemy

              @gameState.next(@turns, size)
          end
      end

      def mountShieldBooster(i)
          if @gameState.state == GameState::INIT || @gameState.state == GameState::AFTERCOMBAT
              @currentStation.mountShieldBooster(i)
          end
      end

      def mountWeapon(i)
          if @gameState.state == GameState::INIT || @gameState.state == GameState::AFTERCOMBAT
              @currentStation.mountWeapon(i)
          end
      end

      def nextTurn
          state = @gameState.state

          if state==GameState::AFTERCOMBAT
              stationState = @currentStation.validState

              if stationState
                  @currentStationIndex = (@currentStationIndex+1)%@spaceStations.length
                  @turns += 1

                  @currentStation = @spaceStations[@currentStationIndex]
                  @currentStation.cleanUpMountedItems
                  dealer = Deepspace::CardDealer.instance
                  @currentEnemy = dealer.nextEnemy
                  @gameState.next(@turns, @spaceStations.length)
                  return true
              else
                  return false
              end
          else
              return false
          end
      end

      def getUIversion
          Deepspace::GameUniverseToUI.new(@currentStation, @currentEnemy)
      end

      def to_s
          message = "GameUniverse(\n" +
                    "\tcurrentStationIndex = " + @currentStationIndex.to_s + "\n" +
                    "\tcurrentStation = " + @currentStation.to_s + "\n" +
                    "\tcurrentEnemy = " + @currentEnemy.to_s + "\n" +
                    "\tturns = " + @turns.to_s + "\n" +
                    "\tdice = " + @dice.to_s + "\n" +
                    "\tgameState = " + @gameState.to_s + "\n" +
                    "\tspaceStations = " + @spaceStations.to_s + "\n" +
                    "\tWIN = " + @@WIN.to_s + "\n" +
                    ")";
          message
      end
  end
end
