# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative 'GameCharacter'

class Dice
  @@NHANGARSPROB = 0.25
  @@NSHIELDSPROB = 0.25
  @@NWEAPONSPROB = 0.33
  @@FIRSTSHOTPROB = 0.5
  
  def initialize()
    
  end
  
  attr_reader :NHANGARSPROB, :NSHIELDSPROB, :NWEAPONSPROB, :FIRSTSHOTPROB
  
  def initWithNHangars
    if rand < @@NHANGARSPROB
      return 0
    else
      return 1
    end
  end
  
  def initWithNWeapons
    random = rand
    if random < @@NWEAPONSPROB
      return 1
    elsif random < 2*@@NWEAPONSPROB
      return 2
    else
      return 3
    end
  end
  
  def initWithNShields
    random = rand
    if random < @@NSHIELDSPROB
      return 0
    else
      return 1
    end
  end
  
  def whoStarts(nPlayers)
    rand(nPlayers)
  end
  
  def firstShot
    random = rand
    if random < @@FIRSTSHOTPROB 
      return GameCharacter::ENEMYSTARSHIP
    else
      return GameCharacter::SPACESTATION
    end
  end
  
  def spaceStationMoves(speed)
    if rand <= speed
      return true
    else
      return false
    end
  end

end
