# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

class SuppliesPackage
  def initialize(ammoPower, fuelUnits, shieldPower)
    @ammoPower = ammoPower
    @fuelUnits = fuelUnits
    @shieldPower = shieldPower
  end
  
  def self.newCopy(s)
    new(s.ammoPower, s.fuelUnits, s.shieldPower)
  end
  
  def to_s
   message = "/SUPPLIESPACKAGE/----   AmmoPower: " + @ammoPower.to_s + " -----   FuelUnits: " + @fuelUnits.to_s +  " -----  ShieldPower: " + @shieldPower.to_s + " \n"; 
   message
  end
  
  attr_reader :ammoPower, :fuelUnits, :shieldPower
  
end
