# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.
require_relative 'LootToUI'

class Loot
  def initialize(nSupplies, nWeapons, nShields, nHangars, nMedals)
    @nSupplies = nSupplies
    @nWeapons = nWeapons
    @nShields = nShields
    @nHangars = nHangars
    @nMedals = nMedals
  end
  
  attr_reader :nSupplies, :nWeapons, :nShields, :nHangars, :nMedals
  
  
  def to_s
   message = "Loot(nSupplies = " + @nSupplies.to_s + 
                ", nWeapons = " + @nWeapons.to_s + 
                ", nShields = " + @nShields.to_s + 
                ", nHangars = " + @nHangars.to_s + 
                ", nMedals = " +  @nMedals.to_s + 
                ")"; 
   message
  end
  
  def getUIversion
   Deepspace::LootToUI.new(self)
  end
end
