# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative 'ShotResult'
require_relative 'SpaceStationToUI'
require_relative 'Hangar'
require_relative 'Weapon'
require_relative 'ShieldBooster'
require_relative 'SuppliesPackage'
require_relative 'Damage'
require_relative 'Loot'
require_relative 'CardDealer'

class SpaceStation
  @@MAXFUEL=100
  @@SHIELDLOSSPERUNITSHOT=0.1
  
  def initialize(name, supplies)
    @ammoPower = supplies.ammoPower
    @fuelUnits = supplies.fuelUnits
    @name = name
    @nMedals = 0
    @shieldPower = supplies.shieldPower
    @pendingDamage = nil
    @weapons = Array.new()
    @shieldBoosters = Array.new()
    @hangar = nil
    
  end
  
  attr_reader :ammoPower, :fuelUnits, :name, :nMedals, :shieldPower, :pendingDamage, :weapons, :shieldBoosters, :hangar
  private
  def assignFuelValue(f)
    if(f< @@MAXFUEL)
      @fuelUnits = f
    end
  end
  
  def cleanPendingDamage
    if @pendingDamage.hasNoeffect
      @pendingDamage= nil
    end
  end
  public
  
  
  def cleanUpMountedItems
    tam = @weapons.length
    tam2 = @shieldBoosters.length
    
    w_removed = Array.new()
    s_removed = Array.new()
    
    i = 0
    while i < tam
      if @weapons[i].uses != 0
        w_removed.push(@weapons[i])
      end
      i+=1
    end
     
   
    
    i = 0
    while i < tam2
      if @shieldBoosters[i].uses != 0
        s_removed.push(@shieldBoosters[i])
      end
      i+=1
    end
    
    @weapons = Array.new(w_removed)
    @shieldBoosters = Array.new(s_removed)

  end
  
  def discardHangar
    @hangar = nil
  end
  
  def discardShieldBooster(i)
    size = @shieldBoosters.length
    if i>=0 && i<size
      s = @shieldBoosters.delete_at(i)
      if @pendingDamage != nil
        @pendingDamage.discardShieldBooster()
        cleanPendingDamage
        
      end
    end
  end
  
  def discardShieldBoosterInHangar(i)
    if @hangar == nil
      @hangar.removeShieldBooster(i)
    end
  end
  
  def discardWeapon(i)
    size = @weapons.length
    if i>=0 && i<size
      w = @weapons.delete_at(i)
      if @pendingDamage != nil
        @pendingDamage.discardWeapon(w)
        cleanPendingDamage
        
      end
    end
  end
  
  def discardWeaponInHangar(i)
    if @hangar == nil
      @hangar.removeWeapon(i)
    end
  end
  
  
  
  def fire
    factor = 1
    i = 0
    while i < @weapons.length 
      factor = factor*@weapons[i].useIt()
      i+=1
    end
    return factor*@ammoPower
  end
  
  
  def getSpeed
    speed = (@fuelUnits/ @@MAXFUEL)
    return speed 
  end
  
  def mountShieldBooster(i)
    if @hangar != nil
      s = @hangar.removeShieldBooster(i)
      if s != nil
        @shieldBoosters.push(s)
      end
    end
  end
  def mountWeapon(i)
    if @hangar != nil
      w = @hangar.removeWeapon(i)
      if w != nil
        @weapons.push(w)
      end
    end
  end
  
  def move
    if 0<= @fuelUnits-getSpeed
      @fuelUnits = @fuelUnits-getSpeed
    end
  end
  
  def protection
    factor = 1
    i = 0
    while i < @shieldBoosters.length 
      factor = factor * @shieldBoosters[i].useIt()
      i+=1
    end
    return factor*@shieldPower
  end
  
  def receiveHangar(h)
    if  @hangar == nil
      @hangar = h
    end
  end
  
  def receiveShieldBooster(s)
    if @hangar != nil
      return @hangar.addShieldBooster(s)
    else
      return false
    end
  end
  
  def receiveShot(shot)
    if protection < shot
      @shieldPower = 0
      return ShotResult::DONOTRESIST
    else
      @shieldPower = @shieldPower - @@SHIELDLOSSPERUNITSHOT*shot
      if @shieldPower<0
        @shieldPower = 0
      end
      return ShotResult::RESIST   
    end
  end
  
  def receiveSupplies(s)
    @ammoPower = @ammoPower + s.ammoPower
    @shieldPower = @shieldPower + s.shieldPower
    
    if(@fuelUnits + s.fuelUnits < @@MAXFUEL)
      @fuelUnits = @fuelUnits + s.fuelUnits
    end
  end
  
  def receiveWeapon(w)
    if @hangar != nil
      return @hangar.addWeapon(w)
    else
      return false
    end
  end
  
  def setLoot(loot)
    dealer = Deepspace::CardDealer.instance
    h = loot.nHangars
    if h>0
      hangar1 = dealer.nextHangar()
      receiveHangar(hangar1)
    end
    nsupplies = loot.nSupplies
    
    i = 0
    while i < nsupplies
      supplies = dealer.nextSuppliesPackage()
      receiveSupplies(supplies)
      i += 1
    end
    
    
    nweapons = loot.nWeapons
    
    i = 0
    while i < nweapons
      w= dealer.nextWeapon
      receiveWeapon(w)
      i += 1
    end
    
    nshields = loot.nShields
    
    i = 0
    while i < nshields
      s= dealer.nextShieldBooster
      receiveShieldBooster(s)
      i += 1
    end
    
    nmedals = loot.nMedals
    @nMedals = @nMedals + nmedals
    
  end
  
  def setPendingDamage(d)
    @pendingDamage = d.adjust(@weapons, @shieldBoosters)
  end
  
  def validState
    return (@pendingDamage == nil || @pendingDamage.hasNoeffect)
  end
  
  def getUIversion
        Deepspace::SpaceStationToUI.new(self)
    end

    def to_s
        message = "SpaceStation(\n" + 
                "\tammoPower = " +  @ammoPower.to_s + "\n" +
                "\tfuelUnits = " + @fuelUnits.to_s + "\n" +
                "\tname = " + @name.to_s + "\n" +
                "\tnMedals = " + @nMedals.to_s + "\n" +
                "\tshieldPower = " + @shieldPower.to_s + "\n" +
                "\tpendingDamage = " + @pendingDamage.to_s + "\n" +
                "\tweapons = " + @weapons.to_s + "\n" +
                "\tshieldBoosters = " + @shieldBoosters.to_s + "\n" +
                "\tHangar = " + @hangar.to_s + "\n" +
                ")";
        
        return message
    end
end
