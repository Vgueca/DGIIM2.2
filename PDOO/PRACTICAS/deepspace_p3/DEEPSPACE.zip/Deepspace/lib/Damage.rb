# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.
require_relative 'DamageToUI'
require_relative 'Weapon'
class Damage
  
  
  def initialize(s,w,array)
    @nShields = s
    @nWeapons = w
    @weapons = array 
  end
  
  attr_reader :nShields, :nWeapons, :weapons
  
  
  
  def self.newNumericWeapons(nw,ns)
    new(ns,nw,nil)
  end
  
  
  
  def self.newSpecificWeapons(w, ns)
    new(ns, -1 , w)
  end
  
  
  
  
  def self.newCopy(d)
    new(d.nShields, d.nWeapons, d.weapons)
  end
  
  
  
  def arrayContainsType(w,t)
    index = -1
    final = false
     
    i = 0  
    while i < w.length && !final 
      if w[i].type == t
        index = i
        final = true
      end
      i += 1
    end
    return index
  end
  
  
  
  
  
  def adjust(w,s)
    min2 = [@nShields, s.length].min
    if @weapons == nil
      min = [@nWeapons, w.length].min
      
      adjusted = Damage.newNumericWeapons(min, min2)
      
      return adjusted
    else
      found = false
      final = false
      
      i = 0
      waux = Array.new(w)
      w2 = Array.new
      while i < @weapons.length 
        j = 0
        while j < waux.length && !final
          if @weapons[i] == waux[j].type
            found = true
            final = true
          end
          j+=1
        end
        if found
          w2.push(@weapons[i])
          waux.delete_at(j-1)
        end
        found = false
        final = false
        i+=1
      end
      if w2.empty?
        w2=nil
      end
      adjusted = Damage.newSpecificWeapons(w2, min2)
    end
    return adjusted
  end
  
  
  
  
  def discardWeapon(w)
    if @weapons != nil
      @weapons.delete(w.type)
    else
      if @nWeapons > 0
        @nWeapons -= 1
      end
      if @nWeapons == 0
        @nWeapons = -1
      end
    end
  end
  
  
  
  
  def discardShieldBooster
    if @nShields > 0
      @nShields -=1
    end
  end
  
  
  
  
  def hasNoeffect
    
    if @nWeapons == 0 && (@weapons == nil || @weapons.empty?) && @nShields == 0
      return true
    elsif @nWeapons == -1 && (@weapons == nil || @weapons.empty?) && @nShields == 0
      return true
    else 
      return false
    end
  end
  
  
  
  def to_s
    if @weapons == nil
      mensaje1 = " "
    else
      mensaje1 = @weapons.to_s
    end
    
    message = "[Damage]: Number of Shields: " + @nShields.to_s +
               ", Number of Weapons: " + @nWeapons.to_s +
               ", Weapon Type: " + mensaje1
    return message
  end
  
  
  def getUIversion
    Deepspace::DamageToUI.new(self)
  end
  
  
  private_class_method :new
end
