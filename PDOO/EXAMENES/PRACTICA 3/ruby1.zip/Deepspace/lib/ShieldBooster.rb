# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.
require_relative 'ShieldToUI'
class ShieldBooster
  def initialize(n,b,u)
    @name = n
    @boost = b
    @uses = u
  end
  attr_reader :name, :boost, :uses
  
  def self.newCopy(s)
    new(s.name,s.boost,s.uses)
  end
  
  def useIt
    if @uses > 0
      @uses -= 1
      return @boost
    else
      return 1.0
    end
    
  end
  
  def to_s
   message = "/ShieldBooster/ ----- Boost: " + @boost.to_s + " ------" + " Uses: " + @uses.to_s;
   message
  end
  
  def getUIversion
    Deepspace::ShieldToUI.new(self)
  end
  
end
