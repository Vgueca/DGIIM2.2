# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.
require_relative 'WeaponToUI'
class Weapon
  def initialize(n,t,u)
    @name = name
    @type = t
    @uses = u
  end
  attr_reader :name, :type, :uses
  
  def self.newCopy(w)
    new(w.name,w.type,w.uses)
  end
  
  def power
    @type.power
  end
  
  def useIt
    if @uses > 0
      @uses = @uses-1
      return power
    else
      return 1.0
    end
    
  end
  
  def to_s
   String message = "/Weapon/ ----- Name: " + @name.to_s + " ----- Type: " + @type.to_s + " ----- Power: " + power.to_s + " ----- Uses: " + @uses.to_s + "\n";
   message
  end
  
  def getUIversion
    Deepspace::WeaponToUI.new(self)
  end
end
