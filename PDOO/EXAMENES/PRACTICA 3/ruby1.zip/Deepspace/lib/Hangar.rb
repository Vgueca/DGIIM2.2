# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.
require_relative 'HangarToUI'
require_relative 'ShieldBooster'
require_relative 'Weapon'

class Hangar
  
  def initialize(c,s=nil,w=nil)
    @maxElements = c
    if s == nil
      @shieldBoosters = Array.new()
    else
      @shieldBoosters = Array.new(s)
    end
    
    if w == nil
      @weapons = Array.new()
    else
      @weapons = Array.new(w)
    end
  end
  
  attr_reader :maxElements, :shieldBoosters, :weapons
  
  def self.newCopy(h)
    new(h.maxElements, h.shieldBoosters, h.weapons) 
  end
  
  def spaceAvailable
    if @maxElements > (@shieldBoosters.length + @weapons.length)
      return true
    else
      return false
    end
  end
  
  def addWeapon(w)
    if spaceAvailable
      @weapons.push(w)
      return true
    else
      return false
    end
  end
  
  def addShieldBooster(s)
    if spaceAvailable
      @shieldBoosters.push(s)
      return true
    else
      return false
    end
  end
  
  def removeShieldBooster(s)
    if @shieldBoosters.length <= s || @shieldBoosters.length == 0
      return nil
    else
      return @shieldBoosters.delete_at(s) 
    end
  end
  
  def removeWeapon(w)
    if @weapons.length <= w || @weapons.length == 0
      return nil
    else
      return @weapons.delete_at(w) 
    end
  end
  
  
   def to_s
     message = " / Hangar / -----  Maxelements: " + @maxElements.to_s + "----- Shields: " + @shieldBoosters.to_s + "----- Weapons: " + @weapons.to_s + "\n";
    return message
  end
  
  
  def getUIversion
    Deepspace::HangarToUI.new(self)
  end
  
  
  
end
