# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative 'Damage'
require_relative 'WeaponType'
require_relative 'Weapon'
module P3

  class ExamenP3
    def initialize
      
    end
    
    def principal
      #Primer ejercicio
      #Comprobado mediante un array que almacena los porcentajes en los que aparecen 2,3 y 4 armas en el damage al crear 1000 de estos objetos.
      damages=Array.new(1000)
      c2 = 0
      c3 = 0
      c4 = 0
      i = 0
      while i < damages.length
        damages[i] = Damage.newRandomWeapons
        if damages[i].nWeapons == 2
          c2 += 1
        elsif damages[i].nWeapons == 3
          c3 +=1
        else
          c4 +=1
        end
        i+=1
      end
      
      percentages = [c2/10.0, c3/10.0, c4/10.0 ]
      puts percentages.inspect
      
      #Segundo ejercicio
      #Comprobado imprimiendo el damage adjustado a los parámetros indicados en el ejercicio
      weapons = [WeaponType::LASER, WeaponType::LASER, WeaponType::MISSILE, WeaponType::MISSILE, WeaponType::PHASER , WeaponType::PHASER , WeaponType::PLASMA , WeaponType::PLASMA]
      
      damage = Damage.newSpecificWeapons(weapons, 0)
      weapons_spacestation = [Weapon.new("PHASER 1", WeaponType::PHASER, 1), Weapon.new("PHASER 2", WeaponType::PHASER, 2), Weapon.new("LASER 1", WeaponType::LASER, 1), \
          Weapon.new("PLASMA 1", WeaponType::PLASMA, 1), Weapon.new("PLASMA 2", WeaponType::PLASMA, 2), Weapon.new("PLASMA 3", WeaponType::PLASMA, 3)]
      shields_spacestation = Array.new
      damage2 = damage.adjust(weapons_spacestation, shields_spacestation)
      
      puts damage2.to_s
      
      
    end
  
  
  
  end
  
  prueba=ExamenP3.new
  prueba.principal


end
